<?php
    function test()
    {
        echo "halo semua";
    }
?> 
